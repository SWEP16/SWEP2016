﻿/// <reference path="../Scripts/jquery-1.7.2.js" />
/// <reference path="../Scripts/jquery.signalR-1.0.1.js" />
$(function () {
    var hub = $.connection.moveShape,
        $shape = $("#shape"),
        $clientCount = $("#clientCount"),
        body = window.document.body;

    // Create a function that the hub can call to broadcast messages.
    hub.client.broadcastMessage = function (name, message) {
        // Html encode display name and message.
        var encodedName = $('<div />').text(name).html();
        var encodedMsg = $('<div />').text(message).html();
        // Add the message to the page.
        $('#discussion').append('<li><strong>' + encodedName
            + '</strong>:&nbsp;&nbsp;' + encodedMsg + '</li>');
    };

    // Get the user name and store it to prepend to messages.
    $('#displayname').val(prompt('Enter your name:', ''));
    // Set initial focus to message input box.
    $('#message').focus();
   
    

    $.extend(hub.client, {
        shapeMoved: function (x, y) {
            $shape.css({
                left: (body.clientWidth - $shape.width()) * x,
                top: (body.clientHeight - $shape.height()) * y
            });
        },
        clientCountChanged: function (count) {
            $clientCount.text(count);
        }
    });

    $.connection.hub.start().done(function () {
        $shape.draggable({
            containment: "parent",
            drag: function () {
                var $this = $(this),
                    x = this.offsetLeft / (body.clientWidth - $this.width()),
                    y = this.offsetTop / (body.clientHeight - $this.height());
                hub.server.moveShape(x, y);
            }
        });
        $('#sendmessage').click(function () {
            // Call the Send method on the hub.
            hub.server.send($('#displayname').val(), $('#message').val());
            // Clear text box and reset focus for next comment.
            $('#message').val('').focus();
        });
    });
});